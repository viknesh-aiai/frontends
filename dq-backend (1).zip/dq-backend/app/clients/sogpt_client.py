from typing import Dict, Any
import requests
from app.core.config import settings
from app.core.logging import logger
from app.clients.sgc_client import sgc_client


class SOGPTClient:
    def _get_headers(self) -> Dict[str, str]:
        token = sgc_client.get_token()
        return {
            "Content-Type": "application/json",
            "X-Application": settings.SOGPT_APP_NAME,
            "X-Key-Name": settings.SOGPT_KEY_NAME,
            "X-Key-Value": settings.SOGPT_KEY_VALUE,
            "X-SGC-Access-Token": token,
            "Authorization": f"Bearer {token}",
        }

    def analyze(self, payload: Dict[str, Any]) -> Dict[str, Any]:
        url = f"{settings.SOGPT_HOST}/api/v2/messages/completions"
        cert = settings.cert_pair if all(settings.cert_pair) else None
        try:
            resp = requests.post(
                url,
                json=payload,
                headers=self._get_headers(),
                verify=settings.ca_verify,
                cert=cert,
                timeout=120,
            )
            resp.raise_for_status()
            logger.info("SOGPT call successful")
            return resp.json()
        except requests.RequestException as e:
            logger.error("SOGPT call failed", error=str(e))
            raise


sogpt_client = SOGPTClient()
