# dq-backend

## Setup
```bash
python -m venv venv
source venv/bin/activate   # Windows: venv\Scripts\activate
pip install -r requirements.txt
# .env already has real credentials pre-filled
python main.py             # runs on http://localhost:8000
```

## Why it works (fix vs old version)
The root cause of the DB connection error was `pydantic-settings` env file path resolution.
This version uses `SettingsConfigDict(env_file=os.path.join(..., ".env"))` exactly like the org
connector code — the `.env` in the project root is correctly loaded regardless of where you
run uvicorn from.

## Endpoints
- `GET  /health`
- `POST /connector/excel/import?app_name=loans`  — upload Excel, extract schema to DB
- `GET  /metadata/apps`                          — list registered app names
- `GET  /metadata/columns?app_name=loans`        — list stored columns
- `GET  /analyze/context?app_name=loans`         — SOGPT NL overview
- `POST /controls/session`                       — start chat session
- `POST /controls/session/{id}/chat`             — send message
- `POST /controls/session/{id}/confirm`          — finalise controls
- `GET  /controls/session/{id}`                  — session status
