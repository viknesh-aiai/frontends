import axios from 'axios';

const API_BASE = import.meta.env.VITE_API_BASE_URL || 'http://localhost:8000';

const api = axios.create({
  baseURL: API_BASE,
  headers: { 'Content-Type': 'application/json' },
});

export async function getAppNames(): Promise<string[]> {
  const res = await api.get('/metadata/apps');
  return res.data.app_names as string[];
}

export async function importExcel(appName: string, files: File[]) {
  const form = new FormData();
  files.forEach(f => form.append('files', f));
  const res = await api.post(
    `/connector/excel/import?app_name=${encodeURIComponent(appName)}`,
    form,
    { headers: { 'Content-Type': 'multipart/form-data' } },
  );
  return res.data;
}

export async function getColumns(appName: string) {
  const res = await api.get('/metadata/columns', { params: { app_name: appName, limit: 2000 } });
  return res.data.items;
}

export async function analyzeContext(appName: string): Promise<string> {
  const res = await api.get('/analyze/context', { params: { app_name: appName } });
  return res.data.context as string;
}

export async function startSession(appNames: string[]) {
  const res = await api.post('/controls/session', { app_names: appNames });
  return res.data;
}

export async function chatSession(sessionId: string, message: string) {
  const res = await api.post(`/controls/session/${sessionId}/chat`, { message });
  return res.data;
}

export async function confirmSession(sessionId: string) {
  const res = await api.post(`/controls/session/${sessionId}/confirm`);
  return res.data;
}
