import requests
from app.core.config import settings
from app.core.logging import logger


class SGCClient:
    def get_token(self) -> str:
        data = {"grant_type": "client_credentials", "scope": settings.SCOPE}
        headers = {"Content-Type": "application/x-www-form-urlencoded"}
        cert = settings.cert_pair if all(settings.cert_pair) else None
        try:
            resp = requests.post(
                settings.SGC_TOKEN_URL,
                data=data,
                headers=headers,
                auth=(settings.SGC_CLIENT_ID, settings.SGC_CLIENT_SECRET),
                timeout=30,
                cert=cert,
                verify=settings.ca_verify,
            )
            resp.raise_for_status()
            token = resp.json().get("access_token")
            logger.info("SGC token obtained")
            return token
        except requests.RequestException as e:
            logger.error("SGC token failed", error=str(e))
            raise


sgc_client = SGCClient()
