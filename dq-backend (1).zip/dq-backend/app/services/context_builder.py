from typing import List, Optional, Dict, Any, Sequence
from sqlalchemy.ext.asyncio import AsyncSession

from app.repositories.metadata_repo import MetadataColumnRepository
from app.services.enrichment import EnrichmentService
from app.db.models.metadata_column import MetadataColumn

repo = MetadataColumnRepository()
enrichment = EnrichmentService()


def _generate_nl_summary(table_name: str, cols: Sequence[MetadataColumn]) -> str:
    all_names = [c.column_name for c in cols]
    keys, pii, temporal = [], [], []
    for c in cols:
        dtype = c.data_type or ""
        if enrichment.is_candidate_key(c.column_name):
            keys.append(c.column_name)
        if enrichment.detect_sensitivity(c.column_name):
            pii.append(f"{c.column_name}(PII)")
        if enrichment.is_temporal(c.column_name, dtype):
            temporal.append(c.column_name)

    parts = [f"Table {table_name} contains {len(cols)} columns: {', '.join(all_names)}."]
    if keys:
        parts.append(f"Primary candidate fields: {', '.join(keys)}.")
    if pii:
        parts.append(f"Likely PII fields: {', '.join(pii)}.")
    if temporal:
        parts.append(f"Temporal fields: {', '.join(temporal)}.")
    return " ".join(parts)


def _parse_nl_summary(nl: str) -> Dict[str, Any]:
    result: Dict[str, Any] = {
        "all_columns": [], "key_columns": [], "pii_columns": [], "temporal_columns": []
    }
    if "columns:" in nl:
        result["all_columns"] = [c.strip() for c in nl.split("columns:", 1)[1].split(".")[0].split(",") if c.strip()]
    if "Primary candidate fields:" in nl:
        result["key_columns"] = [c.strip() for c in nl.split("Primary candidate fields:", 1)[1].split(".")[0].split(",") if c.strip()]
    if "Likely PII fields:" in nl:
        result["pii_columns"] = [c.strip().split("(")[0].strip() for c in nl.split("Likely PII fields:", 1)[1].split(".")[0].split(",") if c.strip()]
    if "Temporal fields:" in nl:
        result["temporal_columns"] = [c.strip() for c in nl.split("Temporal fields:", 1)[1].split(".")[0].split(",") if c.strip()]
    return result


async def build_app_context(
    session: AsyncSession, app_name: str, schema: Optional[str] = None
) -> Dict[str, Any]:
    cols = await repo.get_app_columns(session, app_name, schema)
    groups: Dict[str, Dict[str, list]] = {}
    for c in cols:
        sch = c.table_schema or "public"
        groups.setdefault(sch, {}).setdefault(c.table_name, []).append(c)

    data_dictionary: Dict[str, Dict[str, str]] = {}
    for sch, tables in groups.items():
        data_dictionary[sch] = {}
        for tbl, tcols in tables.items():
            data_dictionary[sch][tbl] = _generate_nl_summary(tbl, tcols)

    return {"app_name": app_name, "data_dictionary": data_dictionary}


async def build_multi_app_context(
    session: AsyncSession, app_names: List[str], schema: Optional[str] = None
) -> Dict[str, Any]:
    apps = []
    for name in app_names:
        ctx = await build_app_context(session, name, schema)
        apps.append(ctx)
    return {"apps": apps}


def build_column_index(raw_metadata: Dict[str, Any]) -> str:
    h = enrichment.h
    lines: List[str] = []

    def _process(app_obj: Dict[str, Any]):
        app_name = app_obj.get("app_name", "unknown")
        dd = app_obj.get("data_dictionary", {})
        lines.append(f"Application: {app_name}")
        for _sch, tables in dd.items():
            for tbl, nl in tables.items():
                parsed = _parse_nl_summary(nl)
                lines.append(f"  TABLE: {tbl}")
                keys = set(parsed["key_columns"])
                piis = set(parsed["pii_columns"])
                temps = set(parsed["temporal_columns"])
                for col in parsed["all_columns"]:
                    tags = []
                    if col in keys:
                        tags.append("[KEY]")
                    if col in temps:
                        tags.append("[DATE]")
                    if col in piis:
                        tags.append("[PII]")
                    if not tags and (
                        any(col.lower().endswith(m) or col.lower().startswith(m) for m in h.measure_hints)
                    ):
                        tags.append("[MEASURE]")
                    lines.append(f"    {col:<35} {' '.join(tags) if tags else '(attribute)'}")
        lines.append("")

    if "apps" in raw_metadata:
        for a in raw_metadata["apps"]:
            _process(a)
    elif "data_dictionary" in raw_metadata:
        _process(raw_metadata)

    return "\n".join(lines).strip()
