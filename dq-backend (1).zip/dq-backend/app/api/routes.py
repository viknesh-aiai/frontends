from __future__ import annotations
from typing import List, Optional

from fastapi import APIRouter, Depends, File, HTTPException, Query, UploadFile
from sqlalchemy.ext.asyncio import AsyncSession

from app.api.schemas import (
    AppContextResponse, AppNamesResponse, ChatRequest, ChatResponse,
    ConfirmResponse, ExcelImportResponse, MetadataColumnOut,
    MetadataColumnsResponse, MultiAppContextResponse, SessionStatusResponse,
    StartSessionRequest, StartSessionResponse,
)
from app.connectors.excel_connector import ExcelConnector
from app.core.db_health import ping_db
from app.core.exceptions import DatabaseError
from app.core.logging import logger
from app.db.session import get_db_session
from app.repositories.metadata_repo import MetadataColumnRepository
from app.services.analysis_service import generate_single_app_context, generate_multi_app_context
from app.services.context_builder import build_app_context, build_multi_app_context
from app.services.conversation_service import conversation_service

router = APIRouter()
_repo = MetadataColumnRepository()
_connector = ExcelConnector()


# ── Health ────────────────────────────────────────────────────────────────────

@router.get("/health")
async def health():
    return {"status": "ok", "service": "dq-backend"}


# ── Connector: Excel import ───────────────────────────────────────────────────

@router.post("/connector/excel/import", response_model=ExcelImportResponse, tags=["connector"])
async def excel_import(
    app_name: str = Query(..., min_length=1),
    files: List[UploadFile] = File(...),
    session: AsyncSession = Depends(get_db_session),
):
    try:
        await ping_db(session)
    except DatabaseError as e:
        raise HTTPException(status_code=500, detail=str(e))

    errors: List[str] = []
    all_payloads = []

    for file in files:
        if not file.filename or not file.filename.lower().endswith(".xlsx"):
            errors.append(f"{file.filename or '<no name>'}: only .xlsx files supported")
            continue
        content = await file.read()
        try:
            payloads = await _connector.extract(app_name=app_name, content=content,
                                                 excel_name=file.filename)
            all_payloads.extend(payloads)
        except Exception as e:
            errors.append(f"{file.filename}: {str(e)}")

    inserted, skipped = 0, 0
    if all_payloads:
        inserted, skipped = await _repo.bulk_import(session, app_name, all_payloads)

    logger.info("Excel import", app_name=app_name, inserted=inserted, skipped=skipped)
    return ExcelImportResponse(app_name=app_name, inserted=inserted, skipped=skipped, errors=errors)


# ── Metadata ──────────────────────────────────────────────────────────────────

@router.get("/metadata/columns", response_model=MetadataColumnsResponse, tags=["metadata"])
async def list_columns(
    app_name: Optional[str] = Query(None),
    limit: int = Query(500, ge=1, le=2000),
    session: AsyncSession = Depends(get_db_session),
):
    try:
        await ping_db(session)
    except DatabaseError as e:
        raise HTTPException(status_code=500, detail=str(e))

    rows = await _repo.list(session, limit=limit, app_name=app_name)
    items = [MetadataColumnOut(
        id=r.id, app_name=r.app_name, source=r.source, excel_name=r.excel_name,
        table_schema=r.table_schema, table_name=r.table_name, column_name=r.column_name,
        data_type=r.data_type, is_nullable=r.is_nullable,
    ) for r in rows]
    return MetadataColumnsResponse(count=len(items), items=items)


@router.get("/metadata/apps", response_model=AppNamesResponse, tags=["metadata"])
async def list_app_names(session: AsyncSession = Depends(get_db_session)):
    try:
        await ping_db(session)
    except DatabaseError as e:
        raise HTTPException(status_code=500, detail=str(e))
    names = await _repo.get_all_app_names(session)
    return AppNamesResponse(app_names=names)


# ── Analyze ───────────────────────────────────────────────────────────────────

@router.get("/analyze/context", response_model=AppContextResponse, tags=["analyze"])
async def analyze_single(
    app_name: str = Query(...),
    schema: Optional[str] = Query(None),
    session: AsyncSession = Depends(get_db_session),
):
    try:
        await ping_db(session)
    except DatabaseError as e:
        raise HTTPException(status_code=500, detail=str(e))

    raw = await build_app_context(session, app_name, schema)
    if not raw.get("data_dictionary"):
        raise HTTPException(status_code=404,
            detail=f"No metadata found for '{app_name}'. Upload an Excel file first.")

    text = generate_single_app_context(app_name, raw)
    if not text:
        raise HTTPException(status_code=502, detail="AI context generation failed.")

    return AppContextResponse(status="success", app_name=app_name, context=text)


@router.get("/analyze/multi", response_model=MultiAppContextResponse, tags=["analyze"])
async def analyze_multi(
    app_name_1: str = Query(...),
    app_name_2: Optional[str] = Query(None),
    app_name_3: Optional[str] = Query(None),
    schema: Optional[str] = Query(None),
    session: AsyncSession = Depends(get_db_session),
):
    try:
        await ping_db(session)
    except DatabaseError as e:
        raise HTTPException(status_code=500, detail=str(e))

    app_names = [n for n in [app_name_1, app_name_2, app_name_3] if n]
    if len(app_names) != len(set(app_names)):
        raise HTTPException(status_code=400, detail="Duplicate app names not allowed.")

    raw = await build_multi_app_context(session, app_names, schema)
    text = generate_multi_app_context(app_names, raw)
    if not text:
        raise HTTPException(status_code=502, detail="AI multi-app context generation failed.")

    return MultiAppContextResponse(status="success", app_names=app_names, context=text)


# ── Controls ──────────────────────────────────────────────────────────────────

@router.post("/controls/session", response_model=StartSessionResponse, tags=["controls"])
async def start_session(body: StartSessionRequest, session: AsyncSession = Depends(get_db_session)):
    if not body.app_names:
        raise HTTPException(status_code=400, detail="app_names must not be empty.")
    if len(body.app_names) > 3:
        raise HTTPException(status_code=400, detail="Maximum 3 app names allowed.")

    try:
        await ping_db(session)
    except DatabaseError as e:
        raise HTTPException(status_code=500, detail=str(e))

    if len(body.app_names) == 1:
        raw = await build_app_context(session, body.app_names[0])
        nl = generate_single_app_context(body.app_names[0], raw)
    else:
        raw = await build_multi_app_context(session, body.app_names)
        nl = generate_multi_app_context(body.app_names, raw)

    if not nl:
        raise HTTPException(status_code=502,
            detail="Could not generate context. Ensure metadata is imported first.")

    result = conversation_service.start_session(body.app_names, nl, raw)
    return StartSessionResponse(status="success", session_id=result["session_id"],
        app_names=result["app_names"], ai_message=result["ai_message"],
        created_at=result["created_at"])


@router.post("/controls/session/{session_id}/chat", response_model=ChatResponse, tags=["controls"])
async def chat(session_id: str, body: ChatRequest):
    try:
        result = conversation_service.chat(session_id, body.message)
    except ValueError as e:
        raise HTTPException(status_code=404, detail=str(e))
    except Exception as e:
        logger.error("Chat error", session_id=session_id, error=str(e))
        raise HTTPException(status_code=500, detail=str(e))

    return ChatResponse(status="success", session_id=result["session_id"],
        app_names=result["app_names"], turn_number=result["turn_number"],
        ai_message=result["ai_message"])


@router.post("/controls/session/{session_id}/confirm", response_model=ConfirmResponse, tags=["controls"])
async def confirm(session_id: str):
    try:
        result = conversation_service.confirm(session_id)
    except ValueError as e:
        raise HTTPException(status_code=404, detail=str(e))
    except Exception as e:
        logger.error("Confirm error", session_id=session_id, error=str(e))
        raise HTTPException(status_code=500, detail=str(e))

    return ConfirmResponse(status="success", session_id=result["session_id"],
        app_names=result["app_names"], controls=result["controls"],
        ai_message=result["ai_message"], confirmed_at=result["confirmed_at"])


@router.get("/controls/session/{session_id}", response_model=SessionStatusResponse, tags=["controls"])
async def get_session(session_id: str):
    result = conversation_service.get_session(session_id)
    if not result:
        raise HTTPException(status_code=404, detail=f"Session not found: {session_id}")
    return SessionStatusResponse(status="success", session_id=session_id,
        app_names=result["app_names"], session_status=result["status"],
        turn_count=result["turn_count"], controls=result["controls"],
        created_at=result["created_at"], updated_at=result["updated_at"],
        confirmed_at=result.get("confirmed_at"))
