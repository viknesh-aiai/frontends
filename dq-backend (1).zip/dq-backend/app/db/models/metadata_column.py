from sqlalchemy import Boolean, Integer, String
from sqlalchemy.orm import Mapped, mapped_column
from app.db.base import Base


class MetadataColumn(Base):
    __tablename__ = "metadata_columns"

    id: Mapped[int] = mapped_column(Integer, primary_key=True, autoincrement=True)
    app_name: Mapped[str] = mapped_column(String(255), index=True)
    source: Mapped[str] = mapped_column(String(32), index=True)
    excel_name: Mapped[str | None] = mapped_column(String(255), index=True, nullable=True)
    table_schema: Mapped[str | None] = mapped_column(String(255), index=True, nullable=True)
    table_name: Mapped[str] = mapped_column(String(255), index=True)
    column_name: Mapped[str] = mapped_column(String(255), index=True)
    data_type: Mapped[str] = mapped_column(String(255))
    is_nullable: Mapped[bool] = mapped_column(Boolean)
