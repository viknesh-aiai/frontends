# dq-dashboard

## Setup
```bash
# Set JFROG_TOKEN env var first (needed for @sg-bootstrap and @sgwt packages from org registry)
export JFROG_TOKEN=your_token_here

npm install
# .env.development already has real org values including localhost.world.socgen redirect

npm run dev    # runs on https://localhost.world.socgen:3000  (if HTTPS certs set)
               # or http://localhost:3000 (without certs)
```

## HTTPS for localhost.world.socgen (required for SG Connect OAuth)
```bash
# Set these to your org SSL cert paths:
export LOCALHOST_CERT=/path/to/localhost.crt
export LOCALHOST_CERT_KEY=/path/to/localhost.key
npm run dev
```

## Structure
- SG Bootstrap shell: exact org Header (white navbar + SgwtAccountCenter), SgwtMiniFooter, SgwtHelpCenter
- Tailwind CSS: all page content (Home, AddApplication, AppDetail, SchemaPanel, ContextPanel, ChatPanel)
- Sidebar: slide-in app list panel (Bootstrap modal backdrop + dark panel)
