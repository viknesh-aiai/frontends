import { useParams, useNavigate } from 'react-router-dom';
import SchemaPanel  from './SchemaPanel';
import ContextPanel from './ContextPanel';
import ChatPanel    from './ChatPanel';

export default function AppDetail() {
  const { appName } = useParams<{ appName: string }>();
  const navigate    = useNavigate();
  const decoded     = appName ? decodeURIComponent(appName) : '';

  if (!decoded) { navigate('/'); return null; }

  return (
    <div style={{ height: 'calc(100vh - 96px)', display: 'flex', flexDirection: 'column', overflow: 'hidden' }}>

      {/* Top bar */}
      <div
        className="flex items-center gap-4 px-6 flex-shrink-0"
        style={{ height: 48, background: '#1e293b', borderBottom: '1px solid rgba(255,255,255,0.08)' }}
      >
        <button
          onClick={() => navigate('/')}
          className="text-gray-400 hover:text-white transition-colors text-sm"
          style={{ background: 'none', border: 'none', cursor: 'pointer' }}
        >
          ← Back
        </button>
        <div style={{ width: 1, height: 20, background: 'rgba(255,255,255,0.15)' }} />

        <div className="flex items-center gap-2">
          <div className="w-6 h-6 rounded-full flex items-center justify-center text-white text-xs font-bold"
               style={{ background: '#4f46e5', minWidth: 24 }}>
            {decoded.charAt(0).toUpperCase()}
          </div>
          <span className="text-white text-sm font-semibold">{decoded}</span>
        </div>

        <div style={{ width: 1, height: 20, background: 'rgba(255,255,255,0.15)' }} />

        {/* Step indicators */}
        {[{ n: 1, label: 'Schema & Overview' }, { n: 2, label: 'Control Studio' }].map(s => (
          <div key={s.n} className="flex items-center gap-1.5">
            <div
              className="w-5 h-5 rounded-full flex items-center justify-center text-white text-xs font-bold"
              style={{ background: '#4f46e5', minWidth: 20 }}
            >
              {s.n}
            </div>
            <span className="text-xs text-gray-300">{s.label}</span>
          </div>
        ))}
      </div>

      {/* 3-panel body */}
      <div className="flex flex-1 overflow-hidden">

        {/* LEFT — dark schema panel */}
        <div
          className="flex flex-col overflow-hidden flex-shrink-0"
          style={{ width: 260, background: '#0f172a', borderRight: '1px solid rgba(255,255,255,0.08)' }}
        >
          <div className="px-4 py-3 flex-shrink-0" style={{ borderBottom: '1px solid rgba(255,255,255,0.08)' }}>
            <p className="text-xs font-semibold uppercase tracking-wider" style={{ color: '#64748b' }}>
              Schema Reference
            </p>
          </div>
          <div className="flex-1 overflow-y-auto p-3">
            <SchemaPanel appName={decoded} />
          </div>
        </div>

        {/* CENTRE — AI overview + chat */}
        <div className="flex-1 flex flex-col overflow-hidden" style={{ borderRight: '1px solid #e5e7eb' }}>
          {/* AI overview strip */}
          <div className="flex-shrink-0 border-b border-gray-200 overflow-y-auto" style={{ maxHeight: 200, background: '#fff' }}>
            <div className="p-4">
              <ContextPanel appName={decoded} />
            </div>
          </div>
          {/* Chat fills remainder */}
          <div className="flex-1 overflow-hidden">
            <ChatPanel appName={decoded} />
          </div>
        </div>

        {/* RIGHT — tips + dimension reference */}
        <div
          className="flex flex-col overflow-hidden flex-shrink-0 bg-white"
          style={{ width: 300 }}
        >
          <div className="px-4 py-3 flex-shrink-0 border-b border-gray-100">
            <p className="text-xs font-semibold uppercase tracking-wider text-gray-500">How to use</p>
          </div>
          <div className="flex-1 overflow-y-auto p-4">
            <div className="space-y-4">
              {[
                { step: '1', title: 'Ask for critical fields', body: 'Type "what are the critical data elements?" — AI lists all KEY, MEASURE, DATE, PII columns immediately.' },
                { step: '2', title: 'Describe your rules', body: '"Loan amounts must be positive" or "customer IDs must not repeat" — AI maps it to the exact column.' },
                { step: '3', title: 'Confirm controls', body: 'Click ✓ when done. AI outputs a final numbered list with dimension tags.' },
              ].map(t => (
                <div key={t.step} className="flex items-start gap-3">
                  <span
                    className="w-6 h-6 rounded-full text-white text-xs font-bold flex items-center justify-center flex-shrink-0 mt-0.5"
                    style={{ background: '#4f46e5', minWidth: 24 }}
                  >
                    {t.step}
                  </span>
                  <div>
                    <p className="text-sm font-semibold text-gray-800">{t.title}</p>
                    <p className="text-xs text-gray-500 mt-0.5 leading-relaxed">{t.body}</p>
                  </div>
                </div>
              ))}

              <div className="pt-3" style={{ borderTop: '1px solid #f1f5f9' }}>
                <p className="text-xs font-semibold uppercase tracking-wider text-gray-500 mb-3">DQ Dimensions</p>
                <div className="flex flex-wrap gap-1.5">
                  {Object.entries({
                    UNIQUENESS:   '#d97706',
                    COMPLETENESS: '#2563eb',
                    VALIDITY:     '#059669',
                    CONSISTENCY:  '#dc2626',
                    ACCURACY:     '#7c3aed',
                    TIMELINESS:   '#0d9488',
                    INTEGRITY:    '#ea580c',
                  }).map(([dim, color]) => (
                    <span
                      key={dim}
                      className="inline-block px-2 py-0.5 text-xs font-bold rounded"
                      style={{ background: `${color}20`, color }}
                    >
                      {dim}
                    </span>
                  ))}
                </div>
              </div>
            </div>
          </div>
        </div>

      </div>
    </div>
  );
}
