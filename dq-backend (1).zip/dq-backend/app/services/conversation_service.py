import uuid
from datetime import datetime
from typing import Dict, Any, Optional, List

from app.core.config import settings
from app.core.logging import logger
from app.clients.sogpt_client import sogpt_client
from app.services.context_builder import build_column_index

_sessions: Dict[str, Dict[str, Any]] = {}


def _system_prompt(app_names: List[str], nl_context: str, raw_metadata: Dict[str, Any]) -> str:
    apps_label = ", ".join(app_names)
    col_index = build_column_index(raw_metadata)
    return f"""You are a Data Quality Assistant helping define data quality controls for: {apps_label}.

=== WHAT THIS APPLICATION DOES ===
{nl_context}
===================================

=== COLUMN REFERENCE ===
Tags explain each column's role:
  [KEY]       identifier / candidate key
  [DATE]      date or timestamp field
  [MEASURE]   numeric amount or value
  [PII]       sensitive / personal data
  (attribute) text, code, or status field

{col_index}
========================

=== DATA QUALITY DIMENSIONS ===
Every control MUST be tagged with one of:
  [UNIQUENESS]    [COMPLETENESS]  [VALIDITY]   [CONSISTENCY]
  [ACCURACY]      [TIMELINESS]    [INTEGRITY]
================================

GREETING — first message only:
Greet briefly. Say you are ready to help define data quality controls for {apps_label}.
Ask which fields or data elements the user wants quality rules on.
Do NOT list controls or mention tables yet.

CRITICAL RULE — WHEN USER ASKS FOR CRITICAL / IMPORTANT FIELDS:
If user asks "what are the critical data elements?", "identify key fields", "what should I check?", "suggest fields":
Immediately scan the COLUMN REFERENCE and list ALL [KEY], [MEASURE], [DATE], [PII] columns grouped by table.
Format:
  Here are the critical business data fields I identified in {apps_label}:
  TABLE_NAME:
    1. column_name [KEY] — unique identifier for each record
    2. column_name [MEASURE] — numeric value field
Then ask: "Which of these would you like to define quality rules for?"

COMPLEX CONTROL RULES — MANDATORY FOR EVERY CONTROL:
NEVER write a control that only says "must not be NULL" or "must not be empty".
Every control must be SPECIFIC, MEASURABLE, and BUSINESS-MEANINGFUL.

Patterns by tag and dimension:
  [KEY]+[UNIQUENESS]:  Each value must appear exactly once. Duplicates indicate data entry errors.
  [KEY]+[INTEGRITY]:   Every value must exist as a valid entry in the referenced domain/parent.
  [DATE]+[TIMELINESS]: Must not be NULL and must fall within the last <N> days from processing date.
  [DATE]+[CONSISTENCY]: start date must always be earlier than end date for the same record.
  [DATE]+[VALIDITY]:   Must follow YYYY-MM-DD and not be a future date beyond today.
  [MEASURE]+[ACCURACY]: Must be a non-negative numeric value greater than zero.
  [MEASURE]+[VALIDITY]: Must fall within expected business range [min, max].
  [PII]+[COMPLETENESS]: Must be populated; blank or placeholder values (N/A, UNKNOWN) not acceptable.
  [PII]+[VALIDITY]:    Must conform to the expected format (PAN: ABCDE1234F, email: x@x.x).
  (attribute)+[VALIDITY]: Must only contain values from the approved reference list.

CONTROL FORMAT:
  Control <N> [<DIMENSION>]: <column_name> (<TABLE_NAME>) — <specific, measurable business rule>

Always confirm the column binding explicitly before writing the control.
After generating controls, ask: "What else would you like to add or modify?"
One short clarifying question maximum if intent is genuinely ambiguous.

When user says done / finalise / confirm / that's all:
Output the complete list preceded by exactly:
=== FINALISED CONTROLS ==="""


def _sogpt_payload(messages: list, app_names: List[str], nl_context: str, raw_metadata: Dict) -> Dict:
    system = _system_prompt(app_names, nl_context, raw_metadata)
    sogpt_msgs = [{"role": "system", "content": [{"type": "text", "text": system}]}]
    for m in messages:
        sogpt_msgs.append({"role": m["role"], "content": [{"type": "text", "text": m["content"]}]})
    return {
        "model": settings.SOGPT_MODEL,
        "temperature": 0.2,
        "max_new_tokens": 900,
        "streaming": False,
        "sampling": True,
        "reasoning_effort": "medium",
        "token_probs": False,
        "parallel_tool_calls": False,
        "tool_choice": "none",
        "messages": sogpt_msgs,
    }


def _parse_controls(text: str) -> List[str]:
    marker = "=== FINALISED CONTROLS ==="
    search = text.split(marker, 1)[1] if marker in text else text
    return [
        line.strip()
        for line in search.splitlines()
        if line.strip().lower().startswith("control ") and ":" in line
    ]


class ConversationService:
    def start_session(self, app_names: List[str], nl_context: str, raw_metadata: Dict) -> Dict:
        if not app_names or len(app_names) > 3:
            raise ValueError("Must provide 1–3 application names.")
        session_id = str(uuid.uuid4())
        apps_label = ", ".join(app_names)
        greeting = (
            f"Hi! I'm ready to help you define data quality controls for {apps_label}. "
            "Which business data elements would you like to put quality rules on? Just tell me."
        )
        now = datetime.utcnow().isoformat()
        _sessions[session_id] = {
            "session_id": session_id,
            "app_names": app_names,
            "nl_context": nl_context,
            "raw_metadata": raw_metadata,
            "messages": [{"role": "assistant", "content": greeting}],
            "controls": [],
            "status": "active",
            "created_at": now,
            "updated_at": now,
        }
        logger.info("Session created", session_id=session_id, apps=app_names)
        return {"session_id": session_id, "app_names": app_names, "status": "active",
                "ai_message": greeting, "created_at": now}

    def chat(self, session_id: str, user_message: str) -> Dict:
        s = _sessions.get(session_id)
        if not s:
            raise ValueError(f"Session not found: {session_id}")
        if s["status"] == "confirmed":
            raise ValueError(f"Session {session_id} already confirmed.")

        s["messages"].append({"role": "user", "content": user_message})
        try:
            payload = _sogpt_payload(s["messages"], s["app_names"], s["nl_context"], s["raw_metadata"])
            raw = sogpt_client.analyze(payload)
            ai_text = raw.get("completion", "").strip()
        except Exception as e:
            s["messages"].pop()
            logger.error("SOGPT chat failed", session_id=session_id, error=str(e))
            raise

        s["messages"].append({"role": "assistant", "content": ai_text})
        s["updated_at"] = datetime.utcnow().isoformat()
        turn = len([m for m in s["messages"] if m["role"] == "user"])
        logger.info("Chat turn", session_id=session_id, turn=turn)
        return {"session_id": session_id, "app_names": s["app_names"],
                "status": s["status"], "turn_number": turn, "ai_message": ai_text}

    def confirm(self, session_id: str) -> Dict:
        s = _sessions.get(session_id)
        if not s:
            raise ValueError(f"Session not found: {session_id}")
        if s["status"] == "confirmed":
            return {"session_id": session_id, "app_names": s["app_names"], "status": "confirmed",
                    "controls": s["controls"], "ai_message": "Already finalised.",
                    "confirmed_at": s.get("confirmed_at")}

        s["messages"].append({"role": "user", "content":
            "We are done. Output all confirmed controls using === FINALISED CONTROLS === format."})
        try:
            payload = _sogpt_payload(s["messages"], s["app_names"], s["nl_context"], s["raw_metadata"])
            raw = sogpt_client.analyze(payload)
            ai_text = raw.get("completion", "").strip()
        except Exception as e:
            s["messages"].pop()
            logger.error("SOGPT confirm failed", session_id=session_id, error=str(e))
            raise

        s["messages"].append({"role": "assistant", "content": ai_text})
        controls = _parse_controls(ai_text)
        now = datetime.utcnow().isoformat()
        s.update({"controls": controls, "status": "confirmed",
                   "confirmed_at": now, "updated_at": now})
        logger.info("Session confirmed", session_id=session_id, controls=len(controls))
        return {"session_id": session_id, "app_names": s["app_names"], "status": "confirmed",
                "controls": controls, "ai_message": ai_text, "confirmed_at": now}

    def get_session(self, session_id: str) -> Optional[Dict]:
        s = _sessions.get(session_id)
        if not s:
            return None
        return {"session_id": session_id, "app_names": s["app_names"], "status": s["status"],
                "turn_count": len([m for m in s["messages"] if m["role"] == "user"]),
                "controls": s["controls"], "created_at": s["created_at"],
                "updated_at": s["updated_at"], "confirmed_at": s.get("confirmed_at")}


conversation_service = ConversationService()
