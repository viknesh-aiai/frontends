from __future__ import annotations
from typing import Iterable, Sequence, Optional

from sqlalchemy import func, select, text
from sqlalchemy.dialects.postgresql import insert as pg_insert
from sqlalchemy.exc import DBAPIError, IntegrityError
from sqlalchemy.ext.asyncio import AsyncSession

from app.db.models.metadata_column import MetadataColumn


class MetadataColumnRepository:

    async def list(
        self, session: AsyncSession, limit: int = 500, app_name: Optional[str] = None
    ) -> Sequence[MetadataColumn]:
        limit = max(1, min(int(limit), 2000))
        stmt = select(MetadataColumn).limit(limit)
        if app_name:
            stmt = stmt.where(
                func.lower(MetadataColumn.app_name) == func.lower(app_name.strip())
            )
        result = await session.execute(stmt)
        return result.scalars().all()

    async def get_all_app_names(self, session: AsyncSession) -> list[str]:
        stmt = select(MetadataColumn.app_name).distinct()
        result = await session.execute(stmt)
        return [row[0] for row in result.all()]

    async def get_app_columns(
        self,
        session: AsyncSession,
        app_name: str,
        schema: Optional[str] = None,
    ) -> Sequence[MetadataColumn]:
        stmt = select(MetadataColumn).where(
            func.lower(MetadataColumn.app_name) == func.lower(app_name.strip())
        )
        if schema:
            stmt = stmt.where(MetadataColumn.table_schema == schema)
        result = await session.execute(stmt)
        return result.scalars().all()

    async def bulk_import(
        self,
        session: AsyncSession,
        app_name: str,
        payloads: Iterable,
    ) -> tuple[int, int]:
        rows_data = [
            {
                "app_name": p.app_name,
                "source": p.source,
                "excel_name": p.excel_name,
                "table_schema": p.table_schema,
                "table_name": p.table_name,
                "column_name": p.column_name,
                "data_type": p.data_type,
                "is_nullable": p.is_nullable,
            }
            for p in payloads
        ]
        if not rows_data:
            return 0, 0

        stmt = (
            pg_insert(MetadataColumn)
            .values(rows_data)
            .on_conflict_do_nothing(
                index_elements=[
                    MetadataColumn.app_name,
                    MetadataColumn.source,
                    MetadataColumn.table_schema,
                    MetadataColumn.table_name,
                    MetadataColumn.column_name,
                ]
            )
            .returning(MetadataColumn.id)
        )

        try:
            result = await session.execute(stmt)
            inserted_ids = result.scalars().all()
            await session.commit()
            inserted = len(inserted_ids)
            skipped = len(rows_data) - inserted
            return inserted, skipped
        except DBAPIError:
            await session.rollback()
            inserted = 0
            skipped = 0
            for v in rows_data:
                row = MetadataColumn(**v)
                session.add(row)
                try:
                    await session.commit()
                    inserted += 1
                except IntegrityError:
                    await session.rollback()
                    skipped += 1
            return inserted, skipped
