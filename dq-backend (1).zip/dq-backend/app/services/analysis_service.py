import json
from typing import Dict, Any, Optional, List

from app.core.config import settings
from app.core.logging import logger
from app.clients.sogpt_client import sogpt_client

SINGLE_SYSTEM = (
    "You are a senior data analyst and data quality expert with deep experience across multiple industries.\n"
    "You will receive raw metadata (table names, column names, data types) for a business application.\n\n"
    "YOUR TASK: Produce a rich, insightful business analysis — what this application does, what business "
    "processes it supports, and what data quality risks it carries.\n\n"
    "STRICT RULES:\n"
    "RULE 1 — TRANSLATE, DO NOT RECITE: Never list column names raw. Translate every name into business meaning.\n"
    "RULE 2 — INFER THE DOMAIN PRECISELY: Do NOT default to 'banking'. Look at every column carefully.\n"
    "RULE 3 — BUSINESS IMPACT FOR EVERY DQ RISK: Explain the business consequence, not the technical symptom.\n"
    "RULE 4 — ONE PASS PER ENTITY, NO REPETITION.\n"
    "RULE 5 — PLAIN ENGLISH PARAGRAPHS ONLY: No bullets, no markdown, no JSON.\n\n"
    "STRUCTURE: Para 1 — business overview and domain. "
    "One paragraph per major entity — purpose, key data, consequences of bad data. "
    "Final paragraph — systemic DQ risks."
)

MULTI_SYSTEM = (
    "You are a senior data architect specialising in cross-system integration and data quality.\n"
    "You will receive raw metadata for multiple business applications.\n\n"
    "YOUR TASK: Produce a rich business analysis covering what each application does, how they relate, "
    "and what data quality risks arise both within and across them.\n\n"
    "STRICT RULES:\n"
    "RULE 1 — TRANSLATE, DO NOT RECITE. RULE 2 — INFER EACH DOMAIN INDEPENDENTLY.\n"
    "RULE 3 — CROSS-APP RELATIONSHIPS ARE THE MOST IMPORTANT PART: shared entities, owner system, "
    "data flow, consequence if they fall out of sync.\n"
    "RULE 4 — BUSINESS IMPACT FOR EVERY DQ RISK. RULE 5 — ONE PASS PER ENTITY.\n"
    "RULE 6 — PLAIN ENGLISH PARAGRAPHS ONLY.\n\n"
    "STRUCTURE: One paragraph per application. Integration and data flow section. "
    "Cross-application DQ risks section."
)


def _payload(system: str, user_text: str, max_tokens: int = 1200) -> Dict[str, Any]:
    return {
        "model": settings.SOGPT_MODEL,
        "temperature": 0.1,
        "max_new_tokens": max_tokens,
        "streaming": False,
        "sampling": True,
        "reasoning_effort": "medium",
        "token_probs": False,
        "parallel_tool_calls": False,
        "tool_choice": "none",
        "messages": [
            {"role": "system", "content": [{"type": "text", "text": system}]},
            {"role": "user",   "content": [{"type": "text", "text": user_text}]},
        ],
    }


def generate_single_app_context(app_name: str, raw_metadata: Dict[str, Any]) -> Optional[str]:
    user = f"Application name: {app_name}\n\nMetadata:\n{json.dumps(raw_metadata, indent=2)}"
    try:
        raw = sogpt_client.analyze(_payload(SINGLE_SYSTEM, user))
        text = raw.get("completion", "").strip()
        if not text:
            logger.error("Empty SOGPT completion", app_name=app_name)
            return None
        return text
    except Exception as e:
        logger.error("SOGPT single app failed", app_name=app_name, error=str(e))
        return None


def generate_multi_app_context(app_names: List[str], raw_metadata: Dict[str, Any]) -> Optional[str]:
    label = ", ".join(app_names)
    user = f"Applications: {label}\n\nMetadata:\n{json.dumps(raw_metadata, indent=2)}"
    try:
        raw = sogpt_client.analyze(_payload(MULTI_SYSTEM, user, max_tokens=1600))
        text = raw.get("completion", "").strip()
        if not text:
            logger.error("Empty SOGPT completion", apps=app_names)
            return None
        return text
    except Exception as e:
        logger.error("SOGPT multi app failed", apps=app_names, error=str(e))
        return None
