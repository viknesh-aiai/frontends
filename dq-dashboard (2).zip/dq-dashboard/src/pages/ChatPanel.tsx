import { useEffect, useRef, useState } from 'react';
import { startSession, chatSession, confirmSession } from '../services/apiService';
import type { ChatMessage } from '../types';

type Status = 'idle' | 'starting' | 'active' | 'thinking' | 'confirming' | 'confirmed' | 'error';

const DIM_COLORS: Record<string, { bg: string; color: string }> = {
  UNIQUENESS:   { bg: 'rgba(251,191,36,0.15)',  color: '#d97706' },
  COMPLETENESS: { bg: 'rgba(96,165,250,0.15)',  color: '#2563eb' },
  VALIDITY:     { bg: 'rgba(52,211,153,0.15)',  color: '#059669' },
  CONSISTENCY:  { bg: 'rgba(248,113,113,0.15)', color: '#dc2626' },
  ACCURACY:     { bg: 'rgba(167,139,250,0.15)', color: '#7c3aed' },
  TIMELINESS:   { bg: 'rgba(45,212,191,0.15)',  color: '#0d9488' },
  INTEGRITY:    { bg: 'rgba(251,146,60,0.15)',  color: '#ea580c' },
};

function DimBadge({ text }: { text: string }) {
  const m = text.match(/\[(UNIQUENESS|COMPLETENESS|VALIDITY|CONSISTENCY|ACCURACY|TIMELINESS|INTEGRITY)\]/);
  if (!m) return null;
  const c = DIM_COLORS[m[1]] || { bg: '#e5e7eb', color: '#374151' };
  return (
    <span
      className="inline-block px-2 py-0.5 text-xs font-bold rounded mr-1"
      style={{ background: c.bg, color: c.color }}
    >
      {m[1]}
    </span>
  );
}

function ControlItem({ index, text }: { index: number; text: string }) {
  const clean = text.replace(/^Control\s+\d+\s+\[[\w]+\]:\s*/i, '').trim();
  return (
    <div className="flex items-start gap-2.5 p-3 bg-white rounded-xl shadow-sm"
         style={{ border: '1px solid #e5e7eb', borderLeft: '3px solid #4f46e5' }}>
      <span
        className="w-6 h-6 rounded-full text-white text-xs font-bold flex items-center justify-center flex-shrink-0 mt-0.5"
        style={{ background: '#4f46e5', minWidth: 24 }}
      >
        {index}
      </span>
      <div className="flex-1 min-w-0">
        <DimBadge text={text} />
        <span className="text-sm text-gray-700 leading-relaxed">{clean}</span>
      </div>
    </div>
  );
}

function Bubble({ msg }: { msg: ChatMessage }) {
  if (msg.isThinking) {
    return (
      <div className="flex items-start gap-2.5">
        <div className="w-7 h-7 rounded-full flex items-center justify-center flex-shrink-0"
             style={{ background: '#eef2ff', minWidth: 28 }}>
          🛡
        </div>
        <div className="px-4 py-2.5 bg-white rounded-2xl shadow-sm flex items-center gap-1"
             style={{ border: '1px solid #e5e7eb', borderBottomLeftRadius: 4 }}>
          {[0, 150, 300].map(d => (
            <span
              key={d}
              className="w-1.5 h-1.5 rounded-full animate-bounce"
              style={{ background: '#818cf8', animationDelay: `${d}ms`, display: 'inline-block' }}
            />
          ))}
        </div>
      </div>
    );
  }

  if (msg.role === 'user') {
    return (
      <div className="flex justify-end msg-enter">
        <div
          className="px-4 py-2.5 text-white rounded-2xl text-sm leading-relaxed whitespace-pre-wrap shadow-sm"
          style={{ background: '#4f46e5', maxWidth: '80%', borderBottomRightRadius: 4 }}
        >
          {msg.text}
        </div>
      </div>
    );
  }

  return (
    <div className="flex items-start gap-2.5 msg-enter">
      <div className="w-7 h-7 rounded-full flex items-center justify-center flex-shrink-0 mt-0.5"
           style={{ background: '#eef2ff', minWidth: 28, fontSize: '0.9rem' }}>
        🛡
      </div>
      <div
        className="px-4 py-2.5 bg-white rounded-2xl text-sm text-gray-800 leading-relaxed whitespace-pre-wrap shadow-sm"
        style={{ border: '1px solid #e5e7eb', borderBottomLeftRadius: 4, maxWidth: '80%' }}
      >
        {msg.text}
      </div>
    </div>
  );
}

export default function ChatPanel({ appName }: { appName: string }) {
  const bottomRef  = useRef<HTMLDivElement>(null);
  const startedRef = useRef(false);
  const taRef      = useRef<HTMLTextAreaElement>(null);

  const [status, setStatus]       = useState<Status>('idle');
  const [sessionId, setSessionId] = useState<string | null>(null);
  const [messages, setMessages]   = useState<ChatMessage[]>([]);
  const [controls, setControls]   = useState<string[]>([]);
  const [input, setInput]         = useState('');
  const [error, setError]         = useState('');

  useEffect(() => {
    bottomRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages]);

  useEffect(() => {
    if (startedRef.current || !appName) return;
    startedRef.current = true;
    setStatus('starting');
    startSession([appName])
      .then(data => {
        setSessionId(data.session_id);
        setMessages([{ id: Date.now(), role: 'assistant', text: data.ai_message }]);
        setStatus('active');
      })
      .catch(e => {
        setError(e?.response?.data?.detail || e.message || 'Failed to start session.');
        setStatus('error');
      });
  }, [appName]);

  async function send() {
    const text = input.trim();
    if (!text || !sessionId || status !== 'active') return;
    const thinkId = Date.now() + 1;
    setMessages(prev => [
      ...prev,
      { id: Date.now(), role: 'user', text },
      { id: thinkId, role: 'assistant', text: '', isThinking: true },
    ]);
    setInput(''); setStatus('thinking'); setError('');
    try {
      const data = await chatSession(sessionId, text);
      setMessages(prev =>
        prev.filter(m => m.id !== thinkId)
            .concat({ id: Date.now(), role: 'assistant', text: data.ai_message }),
      );
      setStatus('active');
    } catch (e: any) {
      setMessages(prev => prev.filter(m => m.id !== thinkId));
      const msg = e?.response?.data?.detail || e.message || 'Send failed.';
      setError(msg); setStatus('active');
    }
  }

  async function confirm() {
    if (!sessionId) return;
    const thinkId = Date.now();
    setMessages(prev => [...prev, { id: thinkId, role: 'assistant', text: '', isThinking: true }]);
    setStatus('confirming');
    try {
      const data = await confirmSession(sessionId);
      setMessages(prev =>
        prev.filter(m => m.id !== thinkId)
            .concat({ id: Date.now(), role: 'assistant', text: data.ai_message }),
      );
      setControls(data.controls || []);
      setStatus('confirmed');
    } catch (e: any) {
      setMessages(prev => prev.filter(m => m.id !== thinkId));
      const msg = e?.response?.data?.detail || e.message || 'Confirm failed.';
      setError(msg); setStatus('active');
    }
  }

  function handleKey(e: React.KeyboardEvent) {
    if (e.key === 'Enter' && !e.shiftKey) { e.preventDefault(); send(); }
  }

  const busy = ['thinking', 'confirming', 'starting'].includes(status);

  return (
    <div className="flex flex-col h-full bg-gray-50 overflow-hidden">
      {/* Header */}
      <div className="px-4 py-3 border-b border-gray-100 bg-white flex items-center justify-between flex-shrink-0">
        <div className="flex items-center gap-2">
          <span>🛡</span>
          <span className="text-sm font-semibold text-gray-800">DataShield AI</span>
          <span
            className="w-1.5 h-1.5 rounded-full"
            style={{
              background: status === 'active' || status === 'thinking' ? '#10b981'
                        : status === 'confirmed' ? '#3b82f6'
                        : status === 'error' ? '#ef4444' : '#9ca3af',
            }}
          />
          <span className="text-xs text-gray-400 capitalize">{status}</span>
        </div>
        {status === 'confirmed' && (
          <button
            onClick={() => {
              startedRef.current = false;
              setStatus('idle'); setSessionId(null);
              setMessages([]); setControls([]); setInput(''); setError('');
              setTimeout(() => {
                startedRef.current = false;
                setStatus('starting');
                startSession([appName])
                  .then(d => { setSessionId(d.session_id); setMessages([{ id: Date.now(), role: 'assistant', text: d.ai_message }]); setStatus('active'); })
                  .catch(e => { setError(e.message); setStatus('error'); });
              }, 50);
            }}
            className="text-xs px-2.5 py-1 rounded-lg border border-gray-200 bg-white text-gray-600 hover:bg-gray-50"
            style={{ cursor: 'pointer' }}
          >
            ↺ New Session
          </button>
        )}
      </div>

      {/* Starting */}
      {status === 'starting' && (
        <div className="flex-1 flex items-center justify-center">
          <div className="text-center">
            <span className="inline-block w-7 h-7 border-2 border-indigo-500 border-t-transparent rounded-full animate-spin mb-3" />
            <p className="text-sm text-gray-500">Starting AI session…</p>
          </div>
        </div>
      )}

      {/* Error */}
      {status === 'error' && (
        <div className="flex-1 flex items-center justify-center p-6">
          <div className="text-center">
            <p className="text-sm text-red-600 mb-3">{error}</p>
            <button
              className="px-4 py-2 rounded-lg text-sm font-medium text-white"
              style={{ background: '#4f46e5', border: 'none', cursor: 'pointer' }}
              onClick={() => { startedRef.current = false; setStatus('idle'); setTimeout(() => { startedRef.current = false; setStatus('starting'); startSession([appName]).then(d => { setSessionId(d.session_id); setMessages([{ id: Date.now(), role: 'assistant', text: d.ai_message }]); setStatus('active'); }).catch(e => { setError(e.message); setStatus('error'); }); }, 50); }}
            >
              Retry
            </button>
          </div>
        </div>
      )}

      {/* Messages */}
      {!['starting', 'error'].includes(status) && (
        <div className="flex-1 overflow-y-auto p-4 space-y-4">
          {messages.map(msg => <Bubble key={msg.id} msg={msg} />)}
          <div ref={bottomRef} />
        </div>
      )}

      {/* Confirmed controls */}
      {status === 'confirmed' && controls.length > 0 && (
        <div className="border-t border-gray-100 p-4 bg-white flex-shrink-0 max-h-64 overflow-y-auto">
          <div className="flex items-center gap-2 mb-3">
            <span>✅</span>
            <span className="text-sm font-semibold text-gray-800">
              {controls.length} Control{controls.length !== 1 ? 's' : ''} Confirmed
            </span>
          </div>
          <div className="space-y-2">
            {controls.map((c, i) => <ControlItem key={i} index={i + 1} text={c} />)}
          </div>
        </div>
      )}

      {/* Input */}
      {['active', 'thinking'].includes(status) && (
        <div className="flex-shrink-0 border-t border-gray-100 bg-white p-3">
          {error && <p className="text-xs text-red-500 mb-2 px-1">{error}</p>}
          <div className="flex items-end gap-2">
            <textarea
              ref={taRef}
              rows={2}
              value={input}
              onChange={e => setInput(e.target.value)}
              onKeyDown={handleKey}
              disabled={busy}
              placeholder='Describe a quality rule… or ask "what are the critical fields?"'
              className="flex-1 resize-none border border-gray-200 rounded-xl px-3 py-2.5 text-sm
                         placeholder-gray-400 focus:outline-none disabled:opacity-50"
              style={{ fontFamily: 'inherit' }}
            />
            <div className="flex flex-col gap-1.5">
              <button
                onClick={send}
                disabled={busy || !input.trim()}
                className="w-9 h-9 rounded-xl text-white text-lg flex items-center justify-center disabled:opacity-50"
                style={{ background: '#4f46e5', border: 'none', cursor: busy || !input.trim() ? 'not-allowed' : 'pointer', minWidth: 36 }}
                title="Send (Enter)"
              >
                {status === 'thinking'
                  ? <span className="inline-block w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin" />
                  : '↑'}
              </button>
              <button
                onClick={confirm}
                disabled={busy}
                className="w-9 h-9 rounded-xl text-white text-lg flex items-center justify-center disabled:opacity-50"
                style={{ background: '#10b981', border: 'none', cursor: busy ? 'not-allowed' : 'pointer', minWidth: 36 }}
                title="Confirm all controls"
              >
                {status === 'confirming'
                  ? <span className="inline-block w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin" />
                  : '✓'}
              </button>
            </div>
          </div>
          <p className="text-xs text-gray-400 mt-1.5 px-1">Enter to send · ✓ to confirm controls</p>
        </div>
      )}
    </div>
  );
}
