import { useEffect, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { getAppNames } from '../services/apiService';

interface Props { isOpen: boolean; onClose: () => void }

export default function Sidebar({ isOpen, onClose }: Props) {
  const [apps, setApps]       = useState<string[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError]     = useState('');
  const navigate = useNavigate();

  useEffect(() => {
    if (!isOpen) return;
    let live = true;
    setLoading(true);
    getAppNames()
      .then(n => live && setApps(n))
      .catch(e => live && setError(e.message || 'Failed to load apps'))
      .finally(() => live && setLoading(false));
    return () => { live = false; };
  }, [isOpen]);

  const go = (name: string) => { navigate(`/app/${encodeURIComponent(name)}`); onClose(); };

  return (
    <>
      {isOpen && (
        <div className="modal-backdrop fade show" onClick={onClose} style={{ zIndex: 1040 }} />
      )}
      <div
        className="d-flex flex-column bg-dark text-light"
        style={{
          position: 'fixed', top: 0, left: 0, height: '100vh', width: 280,
          zIndex: 1045,
          transform: isOpen ? 'translateX(0)' : 'translateX(-100%)',
          transition: 'transform 0.25s ease',
          boxShadow: isOpen ? '4px 0 24px rgba(0,0,0,0.4)' : 'none',
        }}
      >
        {/* Header */}
        <div className="d-flex align-items-center justify-content-between px-3 py-3 border-bottom border-secondary">
          <span className="fw-bold">🗂 Applications</span>
          <button className="btn-close btn-close-white btn-sm" onClick={onClose} aria-label="Close" />
        </div>

        {/* List */}
        <div className="flex-grow-1 overflow-auto py-2">
          {loading && (
            <div className="text-center py-4">
              <div className="spinner-border spinner-border-sm text-light" role="status" />
              <p className="mt-2 small text-secondary">Loading…</p>
            </div>
          )}
          {error && <p className="px-3 py-2 text-danger small">{error}</p>}
          {!loading && !error && apps.length === 0 && (
            <p className="px-3 py-2 text-secondary small">No applications yet. Upload an Excel file first.</p>
          )}
          {!loading && !error && apps.map((name, i) => (
            <button
              key={name}
              onClick={() => go(name)}
              className="d-flex align-items-center gap-3 w-100 border-0 bg-transparent text-light
                         px-3 py-2 text-start border-bottom border-secondary"
              style={{ cursor: 'pointer' }}
            >
              <span
                className="d-inline-flex align-items-center justify-content-center rounded-2 fw-bold small flex-shrink-0"
                style={{ width: 32, height: 32, background: '#4f46e5', color: '#fff' }}
              >
                {i + 1}
              </span>
              <span className="text-truncate">{name}</span>
            </button>
          ))}
        </div>

        <div className="px-3 py-2 small text-secondary border-top border-secondary">
          {apps.length} application{apps.length !== 1 ? 's' : ''}
        </div>
      </div>
    </>
  );
}
