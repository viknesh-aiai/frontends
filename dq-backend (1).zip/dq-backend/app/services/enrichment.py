from typing import Optional
from app.core.heuristics import HeuristicsLoader


class EnrichmentService:
    def __init__(self):
        self.h = HeuristicsLoader.get_instance()

    def normalize_datatype(self, raw: str) -> str:
        r = raw.lower()
        if any(x in r for x in ["int", "serial", "number"]):
            return "integer"
        if any(x in r for x in ["char", "text", "string", "varchar"]):
            return "string"
        if any(x in r for x in ["float", "double", "decimal", "numeric", "precision"]):
            return "float"
        if "bool" in r:
            return "boolean"
        if any(x in r for x in ["date", "time", "timestamp"]):
            return "datetime"
        return "unknown"

    def is_candidate_key(self, col: str) -> bool:
        n = col.lower()
        return any(p in n for p in self.h.candidate_key_patterns)

    def detect_sensitivity(self, col: str) -> Optional[str]:
        n = col.lower()
        return "PII" if any(k in n for k in self.h.pii_keywords) else None

    def is_temporal(self, col: str, dtype: str) -> bool:
        if self.normalize_datatype(dtype) == "datetime":
            return True
        n = col.lower()
        return any(p in n for p in self.h.temporal_patterns)

    def is_measure(self, col: str) -> bool:
        n = col.lower()
        return any(n.endswith(h) or n.startswith(h) for h in self.h.measure_hints)
