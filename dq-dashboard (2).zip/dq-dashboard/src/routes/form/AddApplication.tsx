import { useRef, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { importExcel } from '../../services/apiService';
import type { ImportResult } from '../../types';

const SOURCES = ['Excel', 'PostgreSQL (coming soon)', 'Snowflake (coming soon)', 'Azure SQL (coming soon)'];

export default function AddApplication() {
  const navigate   = useNavigate();
  const inputRef   = useRef<HTMLInputElement>(null);

  const [appName, setAppName]       = useState('');
  const [source, setSource]         = useState('');
  const [files, setFiles]           = useState<File[]>([]);
  const [dragOver, setDragOver]     = useState(false);
  const [loading, setLoading]       = useState(false);
  const [result, setResult]         = useState<ImportResult | null>(null);
  const [error, setError]           = useState('');

  function addFiles(list: FileList | null) {
    if (!list) return;
    const xlsx = Array.from(list).filter(f => f.name.endsWith('.xlsx'));
    if (!xlsx.length) { setError('Only .xlsx files are supported'); return; }
    setError('');
    setFiles(prev => {
      const names = new Set(prev.map(f => f.name));
      return [...prev, ...xlsx.filter(f => !names.has(f.name))];
    });
  }

  async function handleUpload() {
    if (!appName.trim()) { setError('Please enter an application name.'); return; }
    if (source === 'Excel' && files.length === 0) { setError('Please select at least one .xlsx file.'); return; }
    setError(''); setLoading(true); setResult(null);
    try {
      const data = await importExcel(appName.trim(), files);
      setResult(data);
    } catch (e: any) {
      setError(e?.response?.data?.detail || e?.response?.data?.message || e.message || 'Upload failed.');
    } finally {
      setLoading(false);
    }
  }

  return (
    <div className="container py-4" style={{ maxWidth: 760 }}>
      <div className="mb-4">
        <h1 className="text-2xl font-bold text-gray-900">Application Registration Form</h1>
        <p className="text-gray-500 text-sm mt-1">Add applications with their associated files</p>
      </div>

      {!result ? (
        <div className="bg-white border border-gray-200 rounded-xl shadow-sm">
          <div className="px-6 py-4 border-b border-gray-200">
            <h3 className="text-lg font-semibold text-gray-900">Add Application</h3>
          </div>
          <div className="px-6 py-5 flex flex-col gap-4">
            {error && (
              <div className="bg-red-50 border border-red-100 text-red-700 text-sm px-4 py-3 rounded-lg">
                {error}
              </div>
            )}

            {/* Application Name */}
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">
                Application Name
              </label>
              <input
                type="text"
                className="w-full border border-gray-300 rounded-lg px-3 py-2 text-sm
                           focus:outline-none focus:ring-2 focus:ring-indigo-500"
                placeholder="Enter application name"
                value={appName}
                onChange={e => setAppName(e.target.value)}
                disabled={loading}
                onKeyDown={e => e.key === 'Enter' && handleUpload()}
              />
            </div>

            {/* Data Source */}
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">
                Data Source Type
              </label>
              <select
                className="w-full border border-gray-300 rounded-lg px-3 py-2 text-sm bg-white
                           focus:outline-none focus:ring-2 focus:ring-indigo-500"
                value={source}
                onChange={e => { setSource(e.target.value); setFiles([]); setError(''); }}
                disabled={loading}
              >
                <option value="">Select a data source</option>
                {SOURCES.map(s => (
                  <option key={s} value={s} disabled={s !== 'Excel'}>{s}</option>
                ))}
              </select>
            </div>

            {/* File upload — Excel only */}
            {source === 'Excel' && (
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  Files Associated
                </label>
                <div
                  onClick={() => inputRef.current?.click()}
                  onDragOver={e => { e.preventDefault(); setDragOver(true); }}
                  onDragLeave={() => setDragOver(false)}
                  onDrop={e => { e.preventDefault(); setDragOver(false); addFiles(e.dataTransfer.files); }}
                  className="border-2 border-dashed rounded-xl p-8 text-center cursor-pointer transition-all"
                  style={{
                    borderColor: dragOver ? '#4f46e5' : '#d1d5db',
                    background: dragOver ? '#eef2ff' : '#f9fafb',
                  }}
                >
                  <input
                    ref={inputRef}
                    type="file"
                    multiple
                    accept=".xlsx"
                    className="hidden"
                    onChange={e => addFiles(e.target.files)}
                  />
                  <div className="text-3xl mb-2">📂</div>
                  {files.length === 0 ? (
                    <>
                      <p className="text-sm font-medium text-gray-600">
                        {dragOver ? 'Drop your .xlsx files here' : 'Drag & drop .xlsx files or click to browse'}
                      </p>
                      <p className="text-xs text-gray-400 mt-1">Multiple files supported</p>
                    </>
                  ) : (
                    <>
                      <p className="text-sm font-medium text-green-700">
                        {files.length} file{files.length !== 1 ? 's' : ''} selected
                      </p>
                      <p className="text-xs text-gray-500 mt-1">{files.map(f => f.name).join(', ')}</p>
                    </>
                  )}
                </div>
                {files.length > 0 && (
                  <div className="mt-2 flex flex-wrap gap-2">
                    {files.map(f => (
                      <span
                        key={f.name}
                        className="inline-flex items-center gap-1 px-2 py-1 rounded-lg text-xs font-medium"
                        style={{ background: '#eef2ff', color: '#4338ca' }}
                      >
                        📄 {f.name}
                        <button
                          onClick={() => setFiles(prev => prev.filter(x => x.name !== f.name))}
                          className="ml-1 text-indigo-400 hover:text-indigo-700"
                          style={{ background: 'none', border: 'none', cursor: 'pointer' }}
                        >
                          ✕
                        </button>
                      </span>
                    ))}
                  </div>
                )}
              </div>
            )}

            {/* Actions */}
            <div className="flex justify-end gap-2 pt-2">
              <button
                className="px-4 py-2 rounded-lg text-sm font-medium border border-gray-300
                           text-gray-700 bg-white hover:bg-gray-50 transition-colors"
                onClick={() => navigate('/')}
                disabled={loading}
              >
                Cancel
              </button>
              <button
                className="px-5 py-2 rounded-lg text-sm font-semibold text-white transition-colors
                           disabled:opacity-50 disabled:cursor-not-allowed"
                style={{ background: '#e30613' }}
                onClick={handleUpload}
                disabled={loading || !appName.trim() || !source || (source === 'Excel' && files.length === 0)}
              >
                {loading ? (
                  <span className="flex items-center gap-2">
                    <span className="inline-block w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin" />
                    Uploading…
                  </span>
                ) : 'Upload'}
              </button>
            </div>
          </div>
        </div>
      ) : (
        /* Success result */
        <div className="bg-white border border-gray-200 rounded-xl shadow-sm">
          <div className="px-6 py-4 border-b border-gray-200 flex items-center gap-2">
            <span className="text-green-600 text-xl">✓</span>
            <h3 className="text-lg font-semibold text-gray-900">Import Successful</h3>
          </div>
          <div className="px-6 py-5">
            <div className="grid grid-cols-3 gap-4 mb-5">
              {[
                { label: 'Application', value: result.app_name },
                { label: 'Columns Imported', value: result.inserted },
                { label: 'Skipped (duplicates)', value: result.skipped },
              ].map(s => (
                <div key={s.label} className="text-center p-4 bg-gray-50 rounded-xl">
                  <p className="text-2xl font-bold text-indigo-600">{s.value}</p>
                  <p className="text-xs text-gray-500 mt-0.5">{s.label}</p>
                </div>
              ))}
            </div>

            {result.errors.length > 0 && (
              <div className="mb-4 p-3 bg-amber-50 border border-amber-100 rounded-lg text-xs text-amber-700">
                <p className="font-semibold mb-1">Warnings:</p>
                <ul className="list-disc list-inside space-y-0.5">
                  {result.errors.map((e, i) => <li key={i}>{e}</li>)}
                </ul>
              </div>
            )}

            <div className="flex gap-3">
              <button
                className="flex-1 py-2.5 rounded-lg text-sm font-semibold text-white text-center"
                style={{ background: '#4f46e5', border: 'none', cursor: 'pointer' }}
                onClick={() => navigate(`/app/${encodeURIComponent(result.app_name)}`)}
              >
                Open {result.app_name} →
              </button>
              <button
                className="px-4 py-2.5 rounded-lg text-sm font-medium border border-gray-300 text-gray-700 bg-white"
                style={{ cursor: 'pointer' }}
                onClick={() => { setResult(null); setFiles([]); setAppName(''); setSource(''); }}
              >
                Upload Another
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
