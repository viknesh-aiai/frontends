import react from '@vitejs/plugin-react-swc';
import { readFileSync } from 'node:fs';
import { resolve } from 'node:path';
import { defineConfig } from 'vite';

const enableHTTPS = !!process.env.LOCALHOST_CERT && !!process.env.LOCALHOST_CERT_KEY;
const serverOptions = enableHTTPS
  ? {
      https: {
        cert: readFileSync(process.env.LOCALHOST_CERT ?? ''),
        key: readFileSync(process.env.LOCALHOST_CERT_KEY ?? ''),
      },
    }
  : {};

export default defineConfig({
  build: {
    rollupOptions: {
      input: {
        index: resolve(__dirname, 'index.html'),
        'silent-renew': resolve(__dirname, 'silent-renew.html'),
      },
    },
  },
  css: {
    preprocessorOptions: {
      scss: {
        api: 'modern-compiler',
      },
    },
    postcss: './postcss.config.js',
  },
  server: {
    port: 3000,
    host: true,
    ...serverOptions,
  },
  plugins: [react()],
});
