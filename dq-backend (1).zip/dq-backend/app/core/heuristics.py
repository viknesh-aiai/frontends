import os
from dataclasses import dataclass, field
from typing import List
import yaml


@dataclass
class Heuristics:
    pii_keywords: List[str] = field(default_factory=list)
    candidate_key_patterns: List[str] = field(default_factory=list)
    temporal_patterns: List[str] = field(default_factory=list)
    measure_hints: List[str] = field(default_factory=list)


class HeuristicsLoader:
    _instance: Heuristics = None

    @classmethod
    def get_instance(cls) -> Heuristics:
        if cls._instance is None:
            yaml_path = os.path.join(os.path.dirname(__file__), "heuristics.yaml")
            with open(yaml_path, "r") as f:
                data = yaml.safe_load(f)
            cls._instance = Heuristics(
                pii_keywords=data.get("pii_keywords", []),
                candidate_key_patterns=data.get("candidate_key_patterns", []),
                temporal_patterns=data.get("temporal_patterns", []),
                measure_hints=data.get("measure_hints", []),
            )
        return cls._instance
