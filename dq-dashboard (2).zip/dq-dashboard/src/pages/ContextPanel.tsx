import { useState } from 'react';
import { analyzeContext } from '../services/apiService';

export default function ContextPanel({ appName }: { appName: string }) {
  const [context, setContext] = useState('');
  const [loading, setLoading] = useState(false);
  const [error, setError]     = useState('');

  async function generate() {
    setLoading(true); setError('');
    try {
      const text = await analyzeContext(appName);
      setContext(text);
    } catch (e: any) {
      setError(e?.response?.data?.detail || e.message || 'Generation failed');
    } finally {
      setLoading(false);
    }
  }

  return (
    <div className="bg-white rounded-xl border border-gray-100 shadow-sm p-5">
      <div className="flex items-center justify-between mb-4">
        <div className="flex items-center gap-2">
          <span>✨</span>
          <span className="text-sm font-semibold text-gray-900">AI Dataset Overview</span>
        </div>
        <button
          onClick={generate}
          disabled={loading}
          className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg border border-gray-200
                     bg-white text-gray-700 text-xs font-medium hover:bg-gray-50 transition-colors
                     disabled:opacity-50 disabled:cursor-not-allowed"
        >
          {loading ? (
            <>
              <span className="inline-block w-3 h-3 border-2 border-indigo-400 border-t-transparent rounded-full animate-spin" />
              Generating…
            </>
          ) : context ? '↺ Regenerate' : '✨ Generate Overview'}
        </button>
      </div>

      {error && (
        <div className="text-xs text-red-600 bg-red-50 border border-red-100 rounded-lg px-3 py-2 mb-3">
          {error}
        </div>
      )}

      {loading && (
        <div className="space-y-2">
          {[100, 92, 85, 100, 60].map((w, i) => (
            <div key={i} className="h-4 rounded shimmer" style={{ width: `${w}%` }} />
          ))}
        </div>
      )}

      {!loading && context && (
        <p className="text-sm text-gray-700 leading-relaxed whitespace-pre-wrap">{context}</p>
      )}

      {!loading && !context && !error && (
        <div className="text-center py-8 text-gray-400">
          <div className="text-4xl mb-3">📄</div>
          <p className="text-sm">
            Click <strong className="text-gray-600">Generate Overview</strong> to get an AI-powered
            description of this dataset based on its schema.
          </p>
        </div>
      )}
    </div>
  );
}
