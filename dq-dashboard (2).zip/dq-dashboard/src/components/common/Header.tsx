import { useState } from 'react';
import { FormattedMessage } from 'react-intl';
import { NavLink } from 'react-router-dom';
import { SgwtAccountCenter } from '@sgwt/sgwt-widgets-react';
import { clsx } from 'clsx';

const MenuItems: React.FC = () => (
  <>
    <li className="navbar-item">
      <NavLink to="/" className="navbar-link">
        <FormattedMessage id="menu.home" />
      </NavLink>
    </li>
    <li className="navbar-item">
      <NavLink to="/add-application" className="navbar-link">
        <FormattedMessage id="menu.form" />
      </NavLink>
    </li>
  </>
);

export const Header = () => {
  const [isCollapsed, setIsCollapsed] = useState<boolean>(true);

  return (
    <nav className="navbar border-bottom border-top">
      <div className="navbar-title">
        <NavLink to="/" className="navbar-title-link">
          <div className="navbar-logo">
            <img src="/favicon.svg" className="border border-white" alt="Societe Generale" />
          </div>
          <div className="navbar-title-divider"></div>
          <div className="navbar-service-name">
            DAR
            <br />
            DataQuality.ai
          </div>
        </NavLink>
        <button
          className="navbar-menu-btn btn btn-flat btn-xl btn-icon flex-center"
          type="button"
          onClick={() => setIsCollapsed(!isCollapsed)}
          data-bs-offset="0,4"
          aria-expanded={!isCollapsed}
        >
          <i className="icon">menu</i>
        </button>
        <ul
          className={clsx('navbar-menu-dropdown dropdown-menu w-100', !isCollapsed && 'show')}
          data-bs-popper="static"
        >
          <MenuItems />
        </ul>
      </div>
      <div className="navbar-content">
        <ul className="navbar-navigation m-0">
          <MenuItems />
        </ul>
      </div>
      <SgwtAccountCenter
        availableLanguages={['en', 'fr']}
        authentication="sg-connect"
        mode="sg-markets"
      />
    </nav>
  );
};
