from __future__ import annotations
import re
from dataclasses import dataclass
from datetime import date, datetime
from decimal import Decimal
from io import BytesIO
from typing import Any, List

from openpyxl import load_workbook
from app.core.logging import logger


@dataclass
class ColumnPayload:
    app_name: str
    source: str
    excel_name: str
    table_schema: str | None
    table_name: str
    column_name: str
    data_type: str
    is_nullable: bool


def _normalize_header(value: Any) -> str:
    if value is None:
        return ""
    return str(value).strip()


def infer_pg_type(value: Any) -> str:
    if value is None or value == "":
        return "text"
    if isinstance(value, bool):
        return "boolean"
    if isinstance(value, int):
        return "integer"
    if isinstance(value, float):
        return "double precision"
    if isinstance(value, Decimal):
        return "numeric"
    if isinstance(value, datetime):
        return "timestamp"
    if isinstance(value, date):
        return "date"
    s = str(value).strip()
    if re.fullmatch(r"[-+]?\d+", s):
        return "integer"
    if re.fullmatch(r"[-+]?\d*\.\d+", s):
        return "double precision"
    return "text"


def _merge_types(a: str, b: str) -> str:
    if a == b:
        return a
    numeric = {"integer", "double precision", "numeric"}
    if a in numeric and b in numeric:
        if "double precision" in (a, b):
            return "double precision"
        if "numeric" in (a, b):
            return "numeric"
        return "integer"
    if "text" in (a, b):
        return "text"
    if {a, b} == {"date", "timestamp"}:
        return "timestamp"
    if "boolean" in (a, b):
        return "text"
    return "text"


class ExcelConnector:
    async def extract(
        self,
        app_name: str,
        content: bytes,
        excel_name: str,
        default_schema: str | None = None,
        max_scan_rows: int = 200,
    ) -> List[ColumnPayload]:
        wb = load_workbook(filename=BytesIO(content), data_only=True, read_only=True)
        results: List[ColumnPayload] = []

        for sheet_name in wb.sheetnames:
            ws = wb[sheet_name]
            rows_iter = ws.iter_rows(values_only=True)

            try:
                header_row = next(rows_iter)
            except StopIteration:
                continue

            headers = [_normalize_header(h) for h in header_row]
            if not any(headers):
                continue

            inferred: list[str | None] = [None] * len(headers)
            has_null: list[bool] = [False] * len(headers)
            scanned = 0

            for row in rows_iter:
                if scanned >= max_scan_rows:
                    break
                for i, cell in enumerate(row):
                    if i >= len(headers):
                        break
                    if cell is None or cell == "":
                        has_null[i] = True
                        continue
                    t = infer_pg_type(cell)
                    inferred[i] = t if inferred[i] is None else _merge_types(inferred[i], t)
                scanned += 1

            for i, col_name in enumerate(headers):
                if not col_name:
                    continue
                results.append(
                    ColumnPayload(
                        app_name=app_name,
                        source="excel",
                        excel_name=excel_name,
                        table_schema=default_schema,
                        table_name=sheet_name,
                        column_name=col_name,
                        data_type=inferred[i] or "text",
                        is_nullable=has_null[i],
                    )
                )

        logger.info("Excel extraction complete", file=excel_name, columns=len(results))
        return results
