import { useEffect, useState } from 'react';
import { getColumns } from '../services/apiService';
import type { MetadataColumn } from '../types';

interface Group { name: string; cols: MetadataColumn[] }

function tag(col: MetadataColumn): { label: string; bg: string; color: string } {
  const n = col.column_name.toLowerCase();
  const t = (col.data_type || '').toLowerCase();
  const isKey = ['_id','_key','_code','_num','_no','_ref','id_','key_','isin','cusip','lei','bic','iban',
    'trade_id','order_id','transaction_id','loan_id','account_id','customer_id'].some(p => n.includes(p));
  if (isKey) return { label: 'KEY', bg: 'rgba(251,191,36,0.15)', color: '#fbbf24' };
  const isDate = ['_date','_time','_dt','_at','timestamp','maturity','settlement','booking','value_date','expiry']
    .some(p => n.includes(p)) || ['date','timestamp','time'].some(p => t.includes(p));
  if (isDate) return { label: 'DATE', bg: 'rgba(96,165,250,0.15)', color: '#60a5fa' };
  const isPii = ['name','email','phone','address','pan','ssn','aadhar','dob','birth','passport','mobile','contact'].some(p => n.includes(p));
  if (isPii) return { label: 'PII', bg: 'rgba(248,113,113,0.15)', color: '#f87171' };
  const isMeas = ['amount','amt','balance','value','price','rate','fee','total','count','qty','notional','premium','score','limit']
    .some(p => n.endsWith(p) || n.startsWith(p)) || ['int','double','float','decimal','numeric','precision'].some(p => t.includes(p));
  if (isMeas) return { label: 'MEAS', bg: 'rgba(52,211,153,0.15)', color: '#34d399' };
  return { label: 'ATTR', bg: 'rgba(148,163,184,0.1)', color: '#94a3b8' };
}

export default function SchemaPanel({ appName }: { appName: string }) {
  const [groups, setGroups] = useState<Group[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError]   = useState('');
  const [open, setOpen]     = useState<Record<string, boolean>>({});

  useEffect(() => {
    setLoading(true);
    getColumns(appName)
      .then((cols: MetadataColumn[]) => {
        const map: Record<string, MetadataColumn[]> = {};
        cols.forEach(c => { map[c.table_name] = map[c.table_name] || []; map[c.table_name].push(c); });
        const g = Object.entries(map).map(([name, cols]) => ({ name, cols }));
        setGroups(g);
        if (g.length) setOpen({ [g[0].name]: true });
      })
      .catch(e => setError(e.message || 'Failed to load schema'))
      .finally(() => setLoading(false));
  }, [appName]);

  if (loading) return (
    <div className="flex items-center justify-center py-8">
      <span className="inline-block w-5 h-5 border-2 border-indigo-400 border-t-transparent rounded-full animate-spin" />
    </div>
  );

  if (error) return <p className="text-xs px-1 py-2" style={{ color: '#f87171' }}>{error}</p>;

  const totalCols = groups.reduce((s, g) => s + g.cols.length, 0);

  return (
    <div>
      <p className="text-xs mb-3" style={{ color: '#64748b' }}>
        {groups.length} table{groups.length !== 1 ? 's' : ''} · {totalCols} columns
      </p>
      <div className="space-y-1">
        {groups.map(g => (
          <div key={g.name}>
            <button
              onClick={() => setOpen(p => ({ ...p, [g.name]: !p[g.name] }))}
              className="w-full flex items-center justify-between px-3 py-2 rounded-lg text-left transition-colors"
              style={{ background: 'rgba(255,255,255,0.08)', border: 'none', cursor: 'pointer' }}
            >
              <div className="flex items-center gap-2 min-w-0">
                <span style={{ color: '#94a3b8', fontSize: '0.65rem' }}>{open[g.name] ? '▼' : '▶'}</span>
                <span className="text-xs font-semibold truncate" style={{ color: '#e2e8f0' }}>{g.name}</span>
              </div>
              <span className="text-xs flex-shrink-0" style={{ color: '#64748b' }}>{g.cols.length}</span>
            </button>

            {open[g.name] && (
              <div className="ml-1 mt-0.5 pb-1" style={{ borderLeft: '1px solid rgba(255,255,255,0.1)' }}>
                {g.cols.map(col => {
                  const t = tag(col);
                  return (
                    <div
                      key={col.column_name}
                      className="flex items-center justify-between px-3 py-1.5 rounded transition-colors"
                    >
                      <span
                        className="text-xs truncate flex-1 mr-2"
                        style={{ color: '#94a3b8' }}
                        title={col.column_name}
                      >
                        {col.column_name}
                      </span>
                      <div className="flex items-center gap-1 flex-shrink-0">
                        <span className="text-xs" style={{ color: '#475569' }}>{col.data_type}</span>
                        <span
                          className="inline-block px-1.5 py-0.5 text-xs font-bold rounded"
                          style={{ background: t.bg, color: t.color }}
                        >
                          {t.label}
                        </span>
                      </div>
                    </div>
                  );
                })}
              </div>
            )}
          </div>
        ))}
      </div>
    </div>
  );
}
