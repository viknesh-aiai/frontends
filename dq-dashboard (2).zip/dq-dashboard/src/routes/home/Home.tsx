import { useEffect, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { getAppNames } from '../../services/apiService';

export default function Home() {
  const navigate = useNavigate();
  const [apps, setApps]       = useState<string[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    getAppNames()
      .then(setApps)
      .catch(() => setApps([]))
      .finally(() => setLoading(false));
  }, []);

  return (
    <div className="min-h-screen" style={{ background: 'linear-gradient(135deg, #0f172a 0%, #1e1b4b 50%, #0f172a 100%)' }}>

      {/* Hero */}
      <div className="flex flex-col items-center justify-center px-6 py-20 text-center">
        <div
          className="inline-flex items-center gap-2 px-3 py-1 rounded-full text-xs font-medium mb-8"
          style={{ background: 'rgba(99,102,241,0.15)', border: '1px solid rgba(99,102,241,0.3)', color: '#a5b4fc' }}
        >
          <span className="w-1.5 h-1.5 rounded-full animate-pulse" style={{ background: '#818cf8' }} />
          AI-Powered · SOGPT · Societe Generale
        </div>

        <h1 className="text-5xl font-extrabold text-white leading-tight mb-5">
          DAR DataQuality.ai
        </h1>

        <p className="text-lg mb-10 max-w-xl" style={{ color: '#94a3b8' }}>
          Upload Excel data, let the AI understand it, then define precise quality controls through a
          natural conversation — without writing a single line of code.
        </p>

        <div className="flex flex-wrap gap-3 justify-center mb-16">
          <button
            className="inline-flex items-center gap-2 px-6 py-3 rounded-xl text-base font-semibold text-white"
            style={{ background: '#4f46e5' }}
            onClick={() => navigate('/add-application')}
          >
            Upload New Application →
          </button>
          {apps.length > 0 && (
            <button
              className="inline-flex items-center gap-2 px-6 py-3 rounded-xl text-base font-semibold"
              style={{ background: 'rgba(255,255,255,0.08)', border: '1px solid rgba(255,255,255,0.15)', color: '#e2e8f0' }}
              onClick={() => navigate(`/app/${encodeURIComponent(apps[0])}`)}
            >
              Open Latest App
            </button>
          )}
        </div>

        <div className="flex flex-wrap gap-3 justify-center mb-16">
          {['AI Schema Understanding', 'Natural Language Rules', 'Dimension-Tagged Controls', 'SOGPT Powered'].map(f => (
            <span
              key={f}
              className="flex items-center gap-1.5 px-3 py-1.5 rounded-full text-xs"
              style={{ background: 'rgba(255,255,255,0.05)', border: '1px solid rgba(255,255,255,0.1)', color: '#94a3b8' }}
            >
              ✓ {f}
            </span>
          ))}
        </div>
      </div>

      {/* Feature cards */}
      <div className="max-w-5xl mx-auto px-6 pb-12">
        <div className="grid grid-cols-1 gap-4" style={{ gridTemplateColumns: 'repeat(auto-fit, minmax(220px, 1fr))' }}>
          {[
            { icon: '📊', title: 'Schema Intelligence', desc: 'Every sheet parsed automatically. Columns tagged as KEY, DATE, MEASURE, or PII.' },
            { icon: '🧠', title: 'AI Context Generation', desc: 'SOGPT reads your schema and writes a plain English business overview.' },
            { icon: '💬', title: 'Conversational Controls', desc: 'Chat to define quality rules. Each control tagged with a DQ dimension.' },
            { icon: '✅', title: 'Finalised Control List', desc: 'Confirm your session — clean numbered list with dimension tags, ready to hand off.' },
          ].map(f => (
            <div
              key={f.title}
              className="p-5 rounded-xl"
              style={{ background: 'rgba(255,255,255,0.05)', border: '1px solid rgba(255,255,255,0.1)' }}
            >
              <div className="text-2xl mb-3">{f.icon}</div>
              <h3 className="text-sm font-semibold text-white mb-2">{f.title}</h3>
              <p className="text-xs leading-relaxed" style={{ color: '#94a3b8' }}>{f.desc}</p>
            </div>
          ))}
        </div>

        {/* App list */}
        <div className="mt-12">
          <div className="flex items-center justify-between mb-4">
            <p className="text-xs font-semibold uppercase tracking-widest" style={{ color: '#64748b' }}>
              Registered Applications
            </p>
            <button
              className="text-xs"
              style={{ color: '#818cf8', background: 'none', border: 'none', cursor: 'pointer' }}
              onClick={() => navigate('/add-application')}
            >
              + Add New
            </button>
          </div>

          {loading && (
            <div className="grid gap-3" style={{ gridTemplateColumns: 'repeat(auto-fill, minmax(200px, 1fr))' }}>
              {[1, 2, 3].map(i => <div key={i} className="h-20 rounded-xl shimmer" />)}
            </div>
          )}

          {!loading && apps.length === 0 && (
            <div className="text-center py-12 rounded-xl" style={{ border: '1px solid rgba(255,255,255,0.1)' }}>
              <p className="text-sm mb-3" style={{ color: '#64748b' }}>No applications registered yet.</p>
              <button
                className="px-4 py-2 rounded-lg text-sm font-medium text-white"
                style={{ background: '#4f46e5', border: 'none', cursor: 'pointer' }}
                onClick={() => navigate('/add-application')}
              >
                Upload your first Excel file
              </button>
            </div>
          )}

          {!loading && apps.length > 0 && (
            <div className="grid gap-3" style={{ gridTemplateColumns: 'repeat(auto-fill, minmax(200px, 1fr))' }}>
              {apps.map((name, i) => (
                <button
                  key={name}
                  onClick={() => navigate(`/app/${encodeURIComponent(name)}`)}
                  className="text-left p-4 rounded-xl"
                  style={{ background: 'rgba(255,255,255,0.05)', border: '1px solid rgba(255,255,255,0.1)', cursor: 'pointer' }}
                >
                  <div className="flex items-start justify-between gap-2">
                    <div className="min-w-0">
                      <p className="font-semibold truncate text-white text-sm">{name}</p>
                      <span
                        className="inline-flex items-center px-2 py-0.5 rounded-full text-xs font-semibold mt-1.5"
                        style={{ background: 'rgba(16,185,129,0.15)', color: '#34d399' }}
                      >
                        Ready
                      </span>
                    </div>
                    <span style={{ color: '#4f46e5', fontSize: '1.1rem' }}>→</span>
                  </div>
                </button>
              ))}
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
