class DQBackendException(Exception):
    pass

class DQMetadataException(DQBackendException):
    pass

class AppMetadataNotConfiguredException(DQMetadataException):
    pass

class TableNotFoundException(DQMetadataException):
    pass

class DatabaseError(DQBackendException):
    pass
