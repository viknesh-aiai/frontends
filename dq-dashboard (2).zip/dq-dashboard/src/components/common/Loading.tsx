import { useIntl } from 'react-intl';

export const Loading = () => {
  const intl = useIntl();
  return (
    <div className="container py-5 text-center">
      <div className="spinner-border text-primary" role="status" style={{ width: '2rem', height: '2rem' }}>
        <span className="visually-hidden">{intl.formatMessage({ id: 'loading' })}</span>
      </div>
      <p className="mt-3 text-muted small">{intl.formatMessage({ id: 'loading' })}</p>
    </div>
  );
};
