import React, { Suspense, useState } from 'react';
import { BrowserRouter as Router, Route, Routes } from 'react-router-dom';
import { SgwtHelpCenter, SgwtMiniFooter, SgwtWidgetContextProvider } from '@sgwt/sgwt-widgets-react';
import { ErrorBoundary, Header } from './components/common';
import { Loading } from './components/common/Loading';
import { IntlProvider } from './context/IntlContext';
import Sidebar from './components/Sidebar';

import './App.scss';

const PageNotFound   = React.lazy(() => import('./components/common/PageNotFound'));
const Home           = React.lazy(() => import('./routes/home/Home'));
const AddApplication = React.lazy(() => import('./routes/form/AddApplication'));
const AppDetail      = React.lazy(() => import('./pages/AppDetail'));

const App: React.FC = () => {
  const [sidebarOpen, setSidebarOpen] = useState(false);

  return (
    <ErrorBoundary>
      <IntlProvider>
        <SgwtWidgetContextProvider infrastructure="azure">
          <Router>
            <Sidebar isOpen={sidebarOpen} onClose={() => setSidebarOpen(false)} />

            {/* ── Exact org sticky header ── */}
            <div className="sticky-top bg-white shadow-sm" style={{ zIndex: 1035 }}>
              <Header />
            </div>

            {/* ── Sidebar toggle bar ── */}
            <div className="bg-white px-3 py-2 border-bottom">
              <button
                className="btn btn-outline-secondary btn-sm d-inline-flex align-items-center gap-2"
                onClick={() => setSidebarOpen(prev => !prev)}
                aria-label="Toggle application list"
              >
                <span>☰</span>
                <span>Applications</span>
              </button>
            </div>

            {/* ── Main content — Tailwind pages live here ── */}
            <div className="main-content">
              <Suspense fallback={<Loading />}>
                <Routes>
                  <Route path="/"                element={<Home />} />
                  <Route path="/app/:appName"    element={<AppDetail />} />
                  <Route path="/add-application" element={<AddApplication />} />
                  <Route path="*"                element={<PageNotFound />} />
                </Routes>
              </Suspense>
            </div>

            {/* ── SG widgets footer/help ── */}
            <SgwtHelpCenter
              applicationId={import.meta.env.VITE_APP_ID}
              mailSubject="DAR DataQuality.ai — User message"
            />
            <SgwtMiniFooter
              type="compact"
              design="light"
              container="container"
              mode="sg-markets"
              contactUsByHelpCenter="sgwt-help-center"
            />
          </Router>
        </SgwtWidgetContextProvider>
      </IntlProvider>
    </ErrorBoundary>
  );
};

export default App;
