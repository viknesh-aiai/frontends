import os
from contextlib import asynccontextmanager
from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware

from app.core.config import settings
from app.core.logging import setup_logging, logger
from app.core.heuristics import HeuristicsLoader
from app.core.exceptions import (
    AppMetadataNotConfiguredException, TableNotFoundException,
    DatabaseError, DQMetadataException,
)
from app.api.error_handlers import (
    app_metadata_not_configured_handler, table_not_found_handler,
    database_error_handler, dq_metadata_exception_handler,
)
from app.api.routes import router


@asynccontextmanager
async def lifespan(app: FastAPI):
    logger.info("DQ Backend starting", env=settings.ENV)
    os.makedirs(settings.UPLOAD_DIR, exist_ok=True)
    try:
        HeuristicsLoader.get_instance()
        logger.info("Heuristics loaded")
    except Exception as e:
        logger.critical("Failed to load heuristics", error=str(e))
        raise
    yield
    logger.info("DQ Backend shutting down")


def create_app() -> FastAPI:
    setup_logging()

    app = FastAPI(
        title=settings.PROJECT_NAME,
        docs_url="/docs",
        redoc_url="/redoc",
        lifespan=lifespan,
    )

    app.add_middleware(
        CORSMiddleware,
        allow_origins=["*"],
        allow_credentials=True,
        allow_methods=["*"],
        allow_headers=["*"],
    )

    app.include_router(router)

    app.add_exception_handler(AppMetadataNotConfiguredException, app_metadata_not_configured_handler)
    app.add_exception_handler(TableNotFoundException, table_not_found_handler)
    app.add_exception_handler(DatabaseError, database_error_handler)
    app.add_exception_handler(DQMetadataException, dq_metadata_exception_handler)

    return app


app = create_app()
