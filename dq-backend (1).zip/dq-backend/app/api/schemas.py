from typing import List, Optional
from pydantic import BaseModel


class MetadataColumnOut(BaseModel):
    id: Optional[int] = None
    app_name: str
    source: str
    excel_name: Optional[str] = None
    table_schema: Optional[str] = None
    table_name: str
    column_name: str
    data_type: str
    is_nullable: bool

    class Config:
        from_attributes = True


class MetadataColumnsResponse(BaseModel):
    count: int
    items: List[MetadataColumnOut]


class ExcelImportResponse(BaseModel):
    app_name: str
    inserted: int
    skipped: int
    errors: List[str] = []


class AppNamesResponse(BaseModel):
    app_names: List[str]


class AppContextResponse(BaseModel):
    status: str
    app_name: str
    context: str


class MultiAppContextResponse(BaseModel):
    status: str
    app_names: List[str]
    context: str


class StartSessionRequest(BaseModel):
    app_names: List[str]


class StartSessionResponse(BaseModel):
    status: str
    session_id: str
    app_names: List[str]
    ai_message: str
    created_at: str


class ChatRequest(BaseModel):
    message: str


class ChatResponse(BaseModel):
    status: str
    session_id: str
    app_names: List[str]
    turn_number: int
    ai_message: str


class ConfirmResponse(BaseModel):
    status: str
    session_id: str
    app_names: List[str]
    controls: List[str]
    ai_message: str
    confirmed_at: str


class SessionStatusResponse(BaseModel):
    status: str
    session_id: str
    app_names: List[str]
    session_status: str
    turn_count: int
    controls: List[str]
    created_at: str
    updated_at: str
    confirmed_at: Optional[str] = None
