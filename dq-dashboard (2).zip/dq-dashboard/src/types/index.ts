export interface MetadataColumn {
  id?: number;
  app_name: string;
  source: string;
  excel_name?: string;
  table_schema?: string;
  table_name: string;
  column_name: string;
  data_type: string;
  is_nullable: boolean;
}

export interface ChatMessage {
  id: number;
  role: 'user' | 'assistant';
  text: string;
  isThinking?: boolean;
}

export interface ImportResult {
  app_name: string;
  inserted: number;
  skipped: number;
  errors: string[];
}
