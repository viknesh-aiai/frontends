export const BUS_TOPIC_GLOBALLANGUAGE = 'global.language';
export const BUS_TOPIC_SGCONNECT_ACCESSTOKEN = 'sg-connect.access-token';
export const BUS_TOPIC_SGCONNECT_USERCONNECTION = 'sg-connect.user-connection';
export const BUS_TOPIC_SGCONNECT_USERINFO = 'sg-connect.user-info';

type BusEventCallback<T> = (payload: T | undefined) => void;
type SubscriptionHandle<T> = { topic: string; cb: BusEventCallback<T> };

export interface SgWidgetsBus {
  dangerouslyGetCurrentValue<T>(topicName: string): T | undefined;
  subscribe<T>(topicName: string, cb: BusEventCallback<T>): SubscriptionHandle<T>;
  unsubscribe<T>(handle: SubscriptionHandle<T>): void;
}

declare global {
  interface Window {
    SGWTWidgetConfiguration: { bus: SgWidgetsBus };
  }
}

export function getWidgetBus(): SgWidgetsBus | null {
  const cfg = window.SGWTWidgetConfiguration;
  return cfg && cfg.bus ? cfg.bus : null;
}
