const PageNotFound: React.FC = () => (
  <div className="pt-5">
    <sg-error-page
      code={404}
      contact-us="YOUR_TEAM_EMAIL@sgcib.com"
      action-button-link="/"
      action-button-label="Go home"
    />
  </div>
);

export default PageNotFound;
