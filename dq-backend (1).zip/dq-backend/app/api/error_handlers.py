from fastapi import Request
from fastapi.responses import JSONResponse
from app.core.exceptions import (
    AppMetadataNotConfiguredException, TableNotFoundException,
    DatabaseError, DQMetadataException,
)


def app_metadata_not_configured_handler(request: Request, exc: AppMetadataNotConfiguredException):
    return JSONResponse(status_code=404,
                        content={"error": "app_metadata_not_configured", "message": str(exc)})


def table_not_found_handler(request: Request, exc: TableNotFoundException):
    return JSONResponse(status_code=404,
                        content={"error": "table_not_found", "message": str(exc)})


def database_error_handler(request: Request, exc: DatabaseError):
    return JSONResponse(status_code=500,
                        content={"error": "database_error", "message": str(exc)})


def dq_metadata_exception_handler(request: Request, exc: DQMetadataException):
    return JSONResponse(status_code=400,
                        content={"error": "dq_metadata_error", "message": str(exc)})
