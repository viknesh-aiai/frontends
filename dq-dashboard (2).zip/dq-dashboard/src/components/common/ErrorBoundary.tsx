import React, { ReactNode } from 'react';
import { SgwtHelpCenter } from '@sgwt/sgwt-widgets-react';

declare global {
  namespace JSX {
    interface IntrinsicElements {
      'sg-error-page': {
        code: 404 | 500 | 503;
        theme?: 'dark' | 'standard';
        'action-button-label'?: string;
        'action-button-link'?: string;
        'contact-us'?: 'help-center' | string;
        fullscreen?: boolean;
        'description-label'?: string;
        'title-label'?: string;
      };
    }
  }
}

interface State { error: Error | null }
interface Props { children: ReactNode }

export class ErrorBoundary extends React.Component<Props, State> {
  public state: State = { error: null };

  static getDerivedStateFromError(error: Error) { return { error }; }

  public componentDidCatch(e: Error, info: React.ErrorInfo) {
    console.error(`ErrorBoundary: ${e.message}`, info);
  }

  public render() {
    const { error } = this.state;
    if (error) {
      return (
        <div style={{ height: '100vh' }}>
          <SgwtHelpCenter
            applicationId={import.meta.env.VITE_APP_ID}
            messageOnly
            messageTemplate={`Hello support.\n\nI encountered an issue.\n\nError: ${error.message}`}
          />
          <sg-error-page
            code={500}
            action-button-label="Back to home"
            action-button-link="/"
            contact-us="help-center"
            fullscreen={true}
            description-label={error.message}
            title-label="DAR DataQuality.ai — Error"
          />
        </div>
      );
    }
    return this.props.children;
  }
}
